package com.widnd9904.singlediary;

public interface OnTabItemSelectedListener {
    public void onTabSelected(int position);
}
